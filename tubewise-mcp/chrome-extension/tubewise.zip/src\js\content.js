// TubeWise Chrome Extension - Content Script
// This script injects the sidebar into YouTube pages and handles user interactions

// Main class for the TubeWise sidebar
class TubeWiseSidebar {
  constructor() {
    this.sidebarContainer = null;
    this.chatHistory = [];
    this.currentVideoId = null;
    this.currentVideoUrl = null;
    this.isLoading = false;
    
    // Bind methods
    this.initSidebar = this.initSidebar.bind(this);
    this.toggleSidebar = this.toggleSidebar.bind(this);
    this.summarizeVideo = this.summarizeVideo.bind(this);
    this.handleChatSubmit = this.handleChatSubmit.bind(this);
    this.renderChatMessage = this.renderChatMessage.bind(this);
    this.jumpToTimestamp = this.jumpToTimestamp.bind(this);
    this.generateContent = this.generateContent.bind(this);
    
    // Listen for messages from background script and popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'initSidebar') {
        this.initSidebar();
      } else if (request.action === 'updateSettings') {
        // Update settings from popup
        if (request.settings) {
          this.updateSettings(request.settings);
        }
      } else if (request.action === 'getVideoDetails') {
        // Send video details back to popup for queue
        const videoTitle = document.querySelector('h1.title.style-scope.ytd-video-primary-info-renderer')?.textContent.trim();
        const channelElement = document.querySelector('#channel-name #text');
        const channelTitle = channelElement ? channelElement.textContent.trim() : 'YouTube Channel';
        
        sendResponse({
          title: videoTitle || 'YouTube Video',
          channelTitle: channelTitle
        });
        return true; // Keep the channel open for async response
      }
    });
    
    // Initialize when the page loads
    this.initSidebar();
  }
  
  // Extract video ID from URL
  getVideoIdFromUrl(url) {
    const urlParams = new URLSearchParams(new URL(url).search);
    return urlParams.get('v');
  }
  
  // Initialize the sidebar
  initSidebar() {
    // Check if we're on a YouTube video page
    if (!window.location.href.includes('youtube.com/watch')) {
      return;
    }
    
    // Get current video information
    this.currentVideoUrl = window.location.href;
    this.currentVideoId = this.getVideoIdFromUrl(this.currentVideoUrl);
    
    // If the sidebar already exists, just update the video ID
    if (this.sidebarContainer) {
      this.updateVideoInfo();
      return;
    }
    
    // Create sidebar container
    this.sidebarContainer = document.createElement('div');
    this.sidebarContainer.className = 'tubewise-sidebar';
    
    this.sidebarContainer.innerHTML = `
      <div class="tubewise-header">
        <h3>TubeWise</h3>
        <button class="tubewise-close-btn">×</button>
      </div>
      <div class="tubewise-tabs">
        <button class="tubewise-tab-btn active" data-tab="summary">Summary</button>
        <button class="tubewise-tab-btn" data-tab="chat">Chat</button>
        <button class="tubewise-tab-btn" data-tab="content">Generate</button>
        <button class="tubewise-tab-btn" data-tab="transcript">Transcript</button>
      </div>
      <div class="tubewise-tab-content active" id="tubewise-summary-tab">
        <button class="tubewise-summarize-btn">Summarize Video</button>
        <div class="tubewise-summary-content"></div>
      </div>
      <div class="tubewise-tab-content" id="tubewise-chat-tab">
        <div class="tubewise-chat-messages"></div>
        <div class="tubewise-chat-input">
          <textarea placeholder="Ask about this video..."></textarea>
          <button class="tubewise-chat-send-btn">Send</button>
        </div>
        <div class="tubewise-login-prompt" style="display: none;">
          <p>Please log in to use the chat feature</p>
          <button class="tubewise-login-btn">Log In</button>
        </div>
      </div>
      <div class="tubewise-tab-content" id="tubewise-content-tab">
        <div class="tubewise-content-options">
          <h4>Generate content from this video</h4>
          <div class="tubewise-content-buttons">
            <button class="tubewise-content-btn" data-type="twitter">Twitter Thread</button>
            <button class="tubewise-content-btn" data-type="linkedin">LinkedIn Post</button>
            <button class="tubewise-content-btn" data-type="notion">Notion Summary</button>
          </div>
        </div>
        <div class="tubewise-content-result"></div>
        <div class="tubewise-login-prompt" style="display: none;">
          <p>Please log in to generate content</p>
          <button class="tubewise-login-btn">Log In</button>
        </div>
      </div>
      <div class="tubewise-tab-content" id="tubewise-transcript-tab">
        <div class="tubewise-transcript-header">
          <button class="tubewise-load-transcript-btn">Load Full Transcript</button>
          <div class="tubewise-transcript-search">
            <input type="text" placeholder="Search transcript..." class="tubewise-transcript-search-input">
            <button class="tubewise-transcript-search-btn">Search</button>
          </div>
        </div>
        <div class="tubewise-transcript-content"></div>
      </div>
    `;
    
    // Add sidebar to the page
    document.body.appendChild(this.sidebarContainer);
    
    // Add toggle button to YouTube's player
    this.addToggleButton();
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Check if auto-summarize is enabled
    chrome.storage.sync.get(['autoSummarize'], (result) => {
      if (result.autoSummarize) {
        this.summarizeVideo();
      }
    });
  }
  
  // Update settings
  updateSettings(settings) {
    if (settings.sidebarEnabled === false) {
      this.sidebarContainer.style.display = 'none';
    } else if (settings.sidebarEnabled === true) {
      this.sidebarContainer.style.display = 'block';
    }
    
    // Auto-summarize if enabled and not already summarized
    if (settings.autoSummarize && 
        this.sidebarContainer.querySelector('.tubewise-summary-content').innerHTML === '') {
      this.summarizeVideo();
    }
  }
  
  // Set up event listeners for the sidebar
  setupEventListeners() {
    // Close button
    const closeBtn = this.sidebarContainer.querySelector('.tubewise-close-btn');
    closeBtn.addEventListener('click', this.toggleSidebar);
    
    // Tab buttons
    const tabButtons = this.sidebarContainer.querySelectorAll('.tubewise-tab-btn');
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // Remove active class from all tabs and buttons
        tabButtons.forEach(btn => btn.classList.remove('active'));
        this.sidebarContainer.querySelectorAll('.tubewise-tab-content').forEach(tab => {
          tab.classList.remove('active');
        });
        
        // Add active class to clicked button and corresponding tab
        button.classList.add('active');
        const tabName = button.dataset.tab;
        document.getElementById(`tubewise-${tabName}-tab`).classList.add('active');
        
        // Load transcript when switching to transcript tab
        if (tabName === 'transcript' && 
            this.sidebarContainer.querySelector('.tubewise-transcript-content').innerHTML === '') {
          this.loadTranscript();
        }
        
        // Check for authentication when clicking chat or content tabs
        if ((tabName === 'chat' || tabName === 'content')) {
          this.checkAuthentication(tabName);
        }
      });
    });
    
    // Summarize button
    const summarizeBtn = this.sidebarContainer.querySelector('.tubewise-summarize-btn');
    summarizeBtn.addEventListener('click', this.summarizeVideo);
    
    // Chat send button and textarea
    const chatSendBtn = this.sidebarContainer.querySelector('.tubewise-chat-send-btn');
    const chatInput = this.sidebarContainer.querySelector('.tubewise-chat-input textarea');
    
    // Function to send chat message
    const sendChat = () => {
      const query = chatInput.value.trim();
      if (query) {
        this.handleChatSubmit(query);
        chatInput.value = '';
      }
    };
    
    chatSendBtn.addEventListener('click', sendChat);
    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChat();
      }
    });
    
    // Content generation buttons
    const contentButtons = this.sidebarContainer.querySelectorAll('.tubewise-content-btn');
    contentButtons.forEach(button => {
      button.addEventListener('click', () => {
        const contentType = button.dataset.type;
        this.generateContent(contentType);
      });
    });
    
    // Login buttons in prompts
    const loginButtons = this.sidebarContainer.querySelectorAll('.tubewise-login-btn');
    loginButtons.forEach(button => {
      button.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'openPopup' });
      });
    });
    
    // Transcript controls
    const loadTranscriptBtn = this.sidebarContainer.querySelector('.tubewise-load-transcript-btn');
    loadTranscriptBtn.addEventListener('click', () => {
      this.loadTranscript(true); // force reload
    });
    
    // Transcript search
    const transcriptSearchBtn = this.sidebarContainer.querySelector('.tubewise-transcript-search-btn');
    const transcriptSearchInput = this.sidebarContainer.querySelector('.tubewise-transcript-search-input');
    
    transcriptSearchBtn.addEventListener('click', () => {
      const query = transcriptSearchInput.value.trim();
      if (query) {
        this.searchTranscript(query);
      }
    });
    
    transcriptSearchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const query = transcriptSearchInput.value.trim();
        if (query) {
          this.searchTranscript(query);
        }
      }
    });
  }
  
  // Add toggle button to YouTube's player
  addToggleButton() {
    try {
      // Remove existing button if any
      const existingButton = document.querySelector('.tubewise-toggle-btn');
      if (existingButton) {
        existingButton.remove();
      }
      
      // Method 1: Try to add to the YouTube player controls
      const playerControls = document.querySelector('.ytp-right-controls');
      if (playerControls) {
        const toggleButton = document.createElement('button');
        toggleButton.className = 'ytp-button tubewise-toggle-btn';
        toggleButton.title = 'Toggle TubeWise Sidebar';
        toggleButton.innerHTML = `
          <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
            <circle cx="18" cy="18" r="10" fill="#8e24aa" />
            <text x="18" y="22" text-anchor="middle" fill="white" font-family="Arial" font-weight="bold" font-size="10">TW</text>
          </svg>
        `;
        
        // Use bind to preserve the 'this' context
        toggleButton.addEventListener('click', this.toggleSidebar.bind(this));
        playerControls.prepend(toggleButton);
        console.log('TubeWise: Added toggle button to YouTube player controls');
        return;
      }
      
      // Method 2: Create a floating button if player controls not found
      const videoPlayer = document.querySelector('.html5-video-player') || document.querySelector('#movie_player');
      if (videoPlayer) {
        const floatingButton = document.createElement('div');
        floatingButton.className = 'tubewise-toggle-btn tubewise-floating-btn';
        floatingButton.title = 'Toggle TubeWise Sidebar';
        floatingButton.innerHTML = `
          <svg height="24" width="24" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" fill="#8e24aa" />
            <text x="12" y="16" text-anchor="middle" fill="white" font-family="Arial" font-weight="bold" font-size="8">TW</text>
          </svg>
        `;
        
        // Style the floating button - position on LEFT since sidebar is on left
        floatingButton.style.position = 'absolute';
        floatingButton.style.left = '10px'; // Changed from right to left
        floatingButton.style.top = '10px';
        floatingButton.style.width = '32px';
        floatingButton.style.height = '32px';
        floatingButton.style.borderRadius = '50%';
        floatingButton.style.backgroundColor = 'rgba(0, 0, 0, 0.6)';
        floatingButton.style.display = 'flex';
        floatingButton.style.alignItems = 'center';
        floatingButton.style.justifyContent = 'center';
        floatingButton.style.cursor = 'pointer';
        floatingButton.style.zIndex = '9999';
        
        floatingButton.addEventListener('click', this.toggleSidebar.bind(this)); // Fixed context binding
        videoPlayer.appendChild(floatingButton);
        console.log('TubeWise: Added floating toggle button to video player');
        return;
      }
      
      // If we couldn't add the button, retry after a delay
      console.log('TubeWise: Could not find player elements, will retry in 2 seconds');
      setTimeout(() => this.addToggleButton(), 2000);
    } catch (error) {
      console.error('TubeWise: Error adding toggle button:', error);
      setTimeout(() => this.addToggleButton(), 3000);
    }
  }
  
  // Toggle sidebar visibility
  toggleSidebar() {
    if (!this.sidebarContainer) {
      const sidebar = document.querySelector('#tubewise-sidebar');
      if (sidebar) {
        sidebar.classList.toggle('tubewise-sidebar-open');
      }
      return;
    }
    
    this.sidebarContainer.classList.toggle('tubewise-sidebar-open');
    
    // If sidebar is now open, check for conflicts with other extensions
    if (this.sidebarContainer.classList.contains('tubewise-sidebar-open')) {
      this.checkForConflicts();
    } else {
      // Reset any margin adjustments if we close the sidebar
      this.resetLayoutAdjustments();
    }
    console.log('TubeWise: Toggled sidebar visibility');
  }
  
  // Check for conflicts with other extensions (like Sider)
  checkForConflicts() {
    const siderElements = document.querySelectorAll('.sider');
    const otherSidebars = document.querySelectorAll('[id*="sidebar"]:not(#tubewise-sidebar), [class*="sidebar"]:not(.tubewise-sidebar-open)');
    
    // Log detected extensions for debugging
    if (siderElements.length > 0) {
      console.log('TubeWise: Detected Sider extension');
    }
    
    if (otherSidebars.length > 0) {
      console.log('TubeWise: Detected other sidebar elements:', otherSidebars.length);
    }
    
    // Adjust YouTube layout to accommodate our sidebar on the left
    const ytpWatch = document.querySelector('#columns.ytd-watch-flexy');
    if (ytpWatch) {
      ytpWatch.style.marginLeft = '350px';
      ytpWatch.style.width = 'calc(100% - 350px)';
      console.log('TubeWise: Adjusted YouTube layout for left sidebar');
    }
  }
  
  // Reset layout adjustments when sidebar is closed
  resetLayoutAdjustments() {
    const ytpWatch = document.querySelector('#columns.ytd-watch-flexy');
    if (ytpWatch) {
      ytpWatch.style.marginLeft = '';
      ytpWatch.style.width = '';
      console.log('TubeWise: Reset YouTube layout adjustments');
    }
  }
  
  // Update video information when navigating to a new video
  updateVideoInfo() {
    this.currentVideoUrl = window.location.href;
    this.currentVideoId = this.getVideoIdFromUrl(this.currentVideoUrl);
    
    // Clear previous content
    const summaryContent = this.sidebarContainer.querySelector('.tubewise-summary-content');
    summaryContent.innerHTML = '';
    
    const chatMessages = this.sidebarContainer.querySelector('.tubewise-chat-messages');
    chatMessages.innerHTML = '';
    
    const contentResult = this.sidebarContainer.querySelector('.tubewise-content-result');
    contentResult.innerHTML = '';
    
    this.chatHistory = [];
    
    // Check if auto-summarize is enabled
    chrome.storage.sync.get(['autoSummarize'], (result) => {
      if (result.autoSummarize) {
        this.summarizeVideo();
      }
    });
  }
  
  // Summarize the current video
  summarizeVideo() {
    if (this.isLoading) return;
    
    const summaryContent = this.sidebarContainer.querySelector('.tubewise-summary-content');
    summaryContent.innerHTML = '<div class="tubewise-loading">Generating summary...</div>';
    
    this.isLoading = true;
    
    chrome.runtime.sendMessage(
      { action: 'summarizeVideo', videoUrl: this.currentVideoUrl },
      (response) => {
        this.isLoading = false;
        
        if (response && response.success !== false) {
          // Render summary
          summaryContent.innerHTML = `
            <h3>${response.title || 'Video Summary'}</h3>
            <p>${response.summary || ''}</p>
            <h4>Key Points:</h4>
            <ul>
              ${(response.key_points || []).map(point => `
                <li>
                  <span class="tubewise-timestamp" data-time="${point.timestamp}">${point.timestamp}</span>
                  ${point.content}
                </li>
              `).join('')}
            </ul>
          `;
          
          // Add click event to timestamps
          const timestamps = summaryContent.querySelectorAll('.tubewise-timestamp');
          timestamps.forEach(ts => {
            ts.addEventListener('click', () => {
              this.jumpToTimestamp(ts.dataset.time);
            });
          });
        } else {
          // Show error
          summaryContent.innerHTML = `
            <div class="tubewise-error">
              Failed to generate summary: ${response?.error || 'Unknown error'}
            </div>
          `;
        }
      }
    );
  }
  
  // Generate content from the current video
  generateContent(contentType) {
    if (this.isLoading) return;
    
    const contentResult = this.sidebarContainer.querySelector('.tubewise-content-result');
    contentResult.innerHTML = '<div class="tubewise-loading">Generating content...</div>';
    
    this.isLoading = true;
    
    chrome.runtime.sendMessage(
      { action: 'generateContent', videoUrl: this.currentVideoUrl, contentType: contentType },
      (response) => {
        this.isLoading = false;
        
        if (response && response.success !== false) {
          // Render generated content
          let contentTitle = '';
          switch(contentType) {
            case 'twitter':
              contentTitle = 'Twitter Thread';
              break;
            case 'linkedin':
              contentTitle = 'LinkedIn Post';
              break;
            case 'notion':
              contentTitle = 'Notion Summary';
              break;
            default:
              contentTitle = 'Generated Content';
          }
          
          contentResult.innerHTML = `
            <div class="tubewise-content-header">
              <h3>${contentTitle}</h3>
              <button class="tubewise-copy-btn" data-content-type="${contentType}">Copy</button>
            </div>
            <div class="tubewise-content-body">
              ${response.content.replace(/\n/g, '<br>')}
            </div>
          `;
          
          // Add copy button functionality
          const copyBtn = contentResult.querySelector('.tubewise-copy-btn');
          if (copyBtn) {
            copyBtn.addEventListener('click', () => {
              const contentText = response.content;
              navigator.clipboard.writeText(contentText).then(() => {
                copyBtn.textContent = 'Copied!';
                setTimeout(() => {
                  copyBtn.textContent = 'Copy';
                }, 2000);
              });
            });
          }
        } else {
          // Show error
          contentResult.innerHTML = `
            <div class="tubewise-error">
              Failed to generate content: ${response?.error || 'Unknown error'}
            </div>
          `;
        }
      }
    );
  }
  
  // Handle chat submission
  handleChatSubmit(query) {
    if (this.isLoading) return;
    
    const chatMessages = this.sidebarContainer.querySelector('.tubewise-chat-messages');
    
    // Add user message to chat
    this.renderChatMessage(chatMessages, { role: 'user', content: query });
    
    // Add loading message
    const loadingMsg = document.createElement('div');
    loadingMsg.className = 'tubewise-chat-message tubewise-loading-message';
    loadingMsg.innerHTML = '<div class="tubewise-loading">Thinking...</div>';
    chatMessages.appendChild(loadingMsg);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    this.isLoading = true;
    
    chrome.runtime.sendMessage(
      { action: 'chatWithVideo', videoUrl: this.currentVideoUrl, query: query },
      (response) => {
        this.isLoading = false;
        
        // Remove loading message
        chatMessages.removeChild(loadingMsg);
        
        if (response && response.success !== false) {
          // Add AI response to chat
          this.renderChatMessage(chatMessages, { 
            role: 'assistant', 
            content: response.answer || 'I couldn\'t find an answer to that.'
          });
          
          // Add suggestions if provided
          if (response.suggestions && response.suggestions.length > 0) {
            const suggestionsElement = document.createElement('div');
            suggestionsElement.className = 'tubewise-suggestions';
            suggestionsElement.innerHTML = `
              <div class="tubewise-suggestions-title">You might also want to know:</div>
              <ul>
                ${response.suggestions.map(s => `<li>${s}</li>`).join('')}
              </ul>
            `;
            chatMessages.appendChild(suggestionsElement);
            
            // Add click events for timestamps in suggestions if any
            const timestamps = suggestionsElement.querySelectorAll('.tubewise-timestamp');
            timestamps.forEach(ts => {
              ts.addEventListener('click', () => {
                this.jumpToTimestamp(ts.dataset.time);
              });
            });
          }
        } else {
          // Add error message to chat
          this.renderChatMessage(chatMessages, { 
            role: 'assistant', 
            content: `Sorry, I encountered an error: ${response?.error || 'Unknown error'}`
          });
        }
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
      }
    );
  }
  
  // Render a chat message
  renderChatMessage(container, message) {
    const messageElement = document.createElement('div');
    messageElement.className = `tubewise-chat-message tubewise-${message.role}-message`;
    
    // Format message content (handle markdown-like formatting)
    let formattedContent = message.content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')  // Bold
      .replace(/\*(.*?)\*/g, '<em>$1</em>')              // Italic
      .replace(/\n/g, '<br>');                           // Line breaks
    
    messageElement.innerHTML = `
      <div class="tubewise-message-avatar">${message.role === 'user' ? 'You' : 'AI'}</div>
      <div class="tubewise-message-content">${formattedContent}</div>
    `;
    
    container.appendChild(messageElement);
    this.chatHistory.push(message);
  }
  
  // Check if user is authenticated
  checkAuthentication(tabName) {
    chrome.storage.sync.get(['authToken'], (result) => {
      const authToken = result.authToken;
      const tab = this.sidebarContainer.querySelector(`#tubewise-${tabName}-tab`);
      const loginPrompt = tab.querySelector('.tubewise-login-prompt');
      
      if (!authToken) {
        // Show login prompt if not authenticated
        if (loginPrompt) {
          loginPrompt.style.display = 'flex';
          
          // Hide input areas if this is the chat tab
          if (tabName === 'chat') {
            tab.querySelector('.tubewise-chat-input').style.display = 'none';
          }
        }
      } else {
        // Hide login prompt if authenticated
        if (loginPrompt) {
          loginPrompt.style.display = 'none';
          
          // Show input areas if this is the chat tab
          if (tabName === 'chat') {
            tab.querySelector('.tubewise-chat-input').style.display = 'flex';
          }
        }
      }
    });
  }
  
  // Load transcript for the current video
  loadTranscript(forceReload = false) {
    const transcriptContent = this.sidebarContainer.querySelector('.tubewise-transcript-content');
    
    // Don't reload if already loaded and not forced
    if (!forceReload && transcriptContent.innerHTML !== '') {
      return;
    }
    
    // Clear previous content and show loading message
    transcriptContent.innerHTML = '<div class="tubewise-loading">Loading transcript...</div>';
    
    // Fetch transcript from backend
    chrome.storage.sync.get(['apiUrl'], (result) => {
      const apiUrl = result.apiUrl || 'http://localhost:8000/api';
      
      fetch(`${apiUrl}/transcript`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ video_id: this.currentVideoId })
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to load transcript');
        }
        return response.json();
      })
      .then(data => {
        if (!data.transcript || data.transcript.length === 0) {
          transcriptContent.innerHTML = '<div class="tubewise-error">No transcript available for this video.</div>';
          return;
        }
        
        // Clear loading message
        transcriptContent.innerHTML = '';
        
        // Create transcript segments with timestamps
        data.transcript.forEach(segment => {
          const segmentElement = document.createElement('div');
          segmentElement.className = 'tubewise-transcript-segment';
          
          const timestamp = this.formatTime(segment.start);
          
          segmentElement.innerHTML = `
            <span class="tubewise-transcript-time" data-time="${segment.start}">${timestamp}</span>
            <span class="tubewise-transcript-text">${segment.text}</span>
          `;
          
          transcriptContent.appendChild(segmentElement);
          
          // Add click event for timestamp
          const timeElement = segmentElement.querySelector('.tubewise-transcript-time');
          timeElement.addEventListener('click', () => {
            this.jumpToTimestamp(timestamp);
          });
        });
      })
      .catch(error => {
        console.error('Transcript error:', error);
        transcriptContent.innerHTML = `<div class="tubewise-error">Error loading transcript: ${error.message}</div>`;
      });
    });
  }
  
  // Search within the transcript
  searchTranscript(query) {
    const transcriptContent = this.sidebarContainer.querySelector('.tubewise-transcript-content');
    const segments = transcriptContent.querySelectorAll('.tubewise-transcript-segment');
    
    if (segments.length === 0) {
      alert('Please load the transcript first');
      return;
    }
    
    // Clear previous highlights
    segments.forEach(segment => {
      segment.classList.remove('highlight');
      const text = segment.querySelector('.tubewise-transcript-text');
      text.innerHTML = text.textContent;
    });
    
    // Convert to lowercase for case-insensitive search
    const lowerQuery = query.toLowerCase();
    let foundCount = 0;
    let firstMatchElement = null;
    
    segments.forEach(segment => {
      const textElement = segment.querySelector('.tubewise-transcript-text');
      const text = textElement.textContent;
      const lowerText = text.toLowerCase();
      
      if (lowerText.includes(lowerQuery)) {
        // Highlight the segment
        segment.classList.add('highlight');
        foundCount++;
        
        // Store the first match to scroll to it
        if (!firstMatchElement) {
          firstMatchElement = segment;
        }
        
        // Highlight the matching text
        const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        textElement.innerHTML = text.replace(regex, '<mark>$1</mark>');
      }
    });
    
    if (foundCount > 0 && firstMatchElement) {
      // Show the number of matches
      alert(`Found ${foundCount} matches for "${query}"`);
      
      // Scroll to the first match
      firstMatchElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      alert(`No matches found for "${query}"`);
    }
  }
  
  // Format seconds into MM:SS or HH:MM:SS
  formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    } else {
      return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
  }
  
  // Jump to a specific timestamp in the video
  jumpToTimestamp(timestamp) {
    // Handle if timestamp is already in seconds
    let seconds = 0;
    
    if (typeof timestamp === 'number') {
      seconds = timestamp;
    } else {
      // Convert timestamp (00:01:15) to seconds
      const parts = timestamp.split(':').map(Number);
      
      if (parts.length === 3) {
        // Hours:Minutes:Seconds
        seconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
      } else if (parts.length === 2) {
        // Minutes:Seconds
        seconds = parts[0] * 60 + parts[1];
      } else {
        // Just seconds
        seconds = parts[0];
      }
    }
    
    // Get video player and set current time
    const videoPlayer = document.querySelector('video');
    if (videoPlayer) {
      videoPlayer.currentTime = seconds;
      videoPlayer.play();
    }
  }
}

// Initialize the sidebar when the page loads
window.addEventListener('load', () => {
  console.log('TubeWise: Page loaded, initializing sidebar...');
  // Wait a bit for YouTube to fully load
  initializeTubeWise();
});

// Function to initialize TubeWise sidebar
function initializeTubeWise() {
  // Check if we're on a YouTube video page
  if (!window.location.href.includes('youtube.com/watch')) {
    console.log('TubeWise: Not on a YouTube video page, will not initialize');
    return;
  }

  // Check for potential conflicts with other extensions
  const otherSidebars = document.querySelectorAll('.sider, .ytp-right-controls > [class*="extension"], [id*="sidebar"], [class*="sidebar"]');
  if (otherSidebars.length > 0) {
    console.log('TubeWise: Detected potential conflicts with other extensions. Will try to adapt positioning.');
  }
  
  console.log('TubeWise: Creating sidebar instance');
  window.tubeWiseSidebar = new TubeWiseSidebar();
  
  // Forcefully display our toggle button by trying multiple times
  // This ensures our button appears even with other extensions present
  const tryAddButton = (attempt = 1) => {
    if (attempt > 5) return; // Max 5 attempts
    
    console.log(`TubeWise: Trying to add toggle button (attempt ${attempt})...`);
    if (window.tubeWiseSidebar) {
      window.tubeWiseSidebar.addToggleButton();
      // Try again after a delay with increasing intervals
      setTimeout(() => tryAddButton(attempt + 1), 1000 * attempt);
    }
  };
  
  // Start trying to add the button
  tryAddButton();
}

// Listen for page navigation (YouTube is a SPA)
let lastUrl = location.href;
const observer = new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    console.log('TubeWise: URL changed to', location.href);
    
    // Check if we're on a video page
    if (window.location.href.includes('youtube.com/watch')) {
      if (window.tubeWiseSidebar) {
        console.log('TubeWise: Updating existing sidebar for new video');
        window.tubeWiseSidebar.updateVideoInfo();
        window.tubeWiseSidebar.addToggleButton();
      } else {
        console.log('TubeWise: Creating new sidebar for video page');
        initializeTubeWise();
      }
    }
  }
});

observer.observe(document, { subtree: true, childList: true });

// Also check for player changes, as YouTube sometimes loads the player after the page
setInterval(() => {
  if (window.location.href.includes('youtube.com/watch') && 
      window.tubeWiseSidebar && 
      !document.querySelector('.tubewise-toggle-btn')) {
    console.log('TubeWise: No toggle button found, trying to add it again');
    window.tubeWiseSidebar.addToggleButton();
  }
}, 5000);

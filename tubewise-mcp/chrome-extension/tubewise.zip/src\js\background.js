// TubeWise Chrome Extension - Background Script
// This script handles background tasks and communication between the extension and the API

// Configuration
const API_BASE_URL = 'http://localhost:8000/api';

// Initialize extension when installed
chrome.runtime.onInstalled.addListener(() => {
  console.log('TubeWise extension installed');
  
  // Initialize storage with default settings
  chrome.storage.sync.set({
    apiUrl: API_BASE_URL,
    sidebarEnabled: true,
    autoSummarize: false,
    language: 'en'
  });
});

// Listen for messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);
  
  if (request.action === 'summarizeVideo') {
    summarizeVideo(request.videoUrl)
      .then(summary => sendResponse(summary))
      .catch(error => {
        console.error('Error summarizing video:', error);
        sendResponse({ success: false, error: error.message || 'Error summarizing video' });
      });
    return true; // Required for async sendResponse
  }
  
  if (request.action === 'chatWithVideo') {
    chatWithVideo(request.videoUrl, request.query)
      .then(response => sendResponse(response))
      .catch(error => {
        console.error('Error in chat with video:', error);
        sendResponse({ success: false, error: error.message || 'Error in chat with video' });
      });
    return true; // Required for async sendResponse
  }
  
  if (request.action === 'generateContent') {
    generateContent(request.videoUrl, request.contentType)
      .then(content => sendResponse(content))
      .catch(error => {
        console.error('Error generating content:', error);
        sendResponse({ success: false, error: error.message || 'Error generating content' });
      });
    return true; // Required for async sendResponse
  }
  
  if (request.action === 'getSettings') {
    chrome.storage.sync.get(['apiUrl', 'sidebarEnabled', 'autoSummarize', 'language', 'authToken', 'user', 'videoQueue'], (result) => {
      sendResponse(result);
    });
    return true; // Required for async sendResponse
  }
  
  if (request.action === 'saveSettings') {
    chrome.storage.sync.set(request.settings, () => {
      sendResponse({ success: true });
    });
    return true; // Required for async sendResponse
  }
  
  if (request.action === 'openPopup') {
    try {
      // Open the popup programmatically
      chrome.action.openPopup();
      sendResponse({ success: true });
    } catch (error) {
      console.error('Error opening popup:', error);
      // If openPopup is not supported (it's an experimental API), fall back to creating a new tab
      chrome.tabs.create({ url: chrome.runtime.getURL('src/popup/popup.html') });
      sendResponse({ success: true, fallback: true });
    }
    return true;
  }
});

// Function to summarize a video
async function summarizeVideo(videoUrl) {
  try {
    const settings = await getSettings();
    // Extract video ID from URL
    const videoId = getVideoIdFromUrl(videoUrl);
    if (!videoId) {
      throw new Error('Invalid video URL');
    }
    
    // Use the new API endpoint format
    const response = await fetch(`${settings.apiUrl}/summarize/${videoId}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error summarizing video:', error);
    throw error;
  }
}

// Function to chat with a video
async function chatWithVideo(videoUrl, query) {
  try {
    const settings = await getSettings();
    const response = await fetch(`${settings.apiUrl}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        video_url: videoUrl,
        query: query
      })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error chatting with video:', error);
    throw error;
  }
}

// Extract video ID from URL
function getVideoIdFromUrl(url) {
  try {
    const urlParams = new URLSearchParams(new URL(url).search);
    return urlParams.get('v');
  } catch (error) {
    console.error('Error extracting video ID:', error);
    return null;
  }
}

// Function to generate content from a video
async function generateContent(videoUrl, contentType) {
  try {
    const settings = await getSettings();
    const videoId = getVideoIdFromUrl(videoUrl);
    if (!videoId) {
      throw new Error('Invalid video URL');
    }
    
    const response = await fetch(`${settings.apiUrl}/generate-content`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        video_id: videoId,
        content_type: contentType // e.g., 'twitter', 'linkedin', 'notion'
      })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error generating content:', error);
    throw error;
  }
}

// Helper function to get settings
function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['apiUrl', 'sidebarEnabled', 'autoSummarize', 'language'], (result) => {
      resolve(result);
    });
  });
}

// Listen for tab updates to inject sidebar when on YouTube
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('youtube.com/watch')) {
    chrome.tabs.sendMessage(tabId, { action: 'initSidebar' });
  }
});
